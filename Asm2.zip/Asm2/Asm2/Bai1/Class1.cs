﻿namespace Bai1
{
    public class Class1
    {
        public int Thuong(int a, int b)
        {
            if (b == 0)
            {
                return 0;
            }
            return a / b;
        }
    }
}
