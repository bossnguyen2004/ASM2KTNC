﻿namespace Calculator
{
    public class Class1
    {

    }
}
